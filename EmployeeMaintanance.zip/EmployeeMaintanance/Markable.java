package EmployeeMaintanance;

public interface Markable{
     void markAttendance(int[] attendanceArray) ;
      int calculatePresentDays(int[] attendanceArray)
      
}